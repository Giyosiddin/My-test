<?php $__env->startSection('content'); ?>
	
                <form method="post" action="<?php echo e(route('upload')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="col-md-3">Select images</div>
                        <div class="col-md-9">
                            <input type="file" name="file[]" id="file"> 
                        </div>
                        <input type="submit" name="upload">
                    </div>

                </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>