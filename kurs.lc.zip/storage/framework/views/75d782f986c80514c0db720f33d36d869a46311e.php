<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <nav class="navbar navbar-toggleable-md navbar-light bg-faded">
                    <a href="<?php echo e(route('blog.admin.posts.create')); ?>" class="btn btn-primary">Добавить</a>
                </nav>
                <div class="card">
                    <div class="card-body">
                        <h2>Post index</h2>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Автор</th>
                                <th scope="col">Категория</th>
                                <th scope="col">Заголовок</th>
                                <th scope="col">Дата публикации</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $paginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr <?php if(!$item->published_at): ?> style="background: #ccc;" <?php endif; ?>>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->user->name); ?></td>
                                    <td><?php echo e($item->category->title); ?></td>
                                    <td><a href="<?php echo e(route('blog.admin.posts.edit', [$item->id])); ?>"><?php echo e($item->title); ?></a></td>
                                    <td><?php echo e($item->published_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php echo e($paginator->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>