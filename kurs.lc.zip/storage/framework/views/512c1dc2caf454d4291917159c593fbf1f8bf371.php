<?php $__env->startSection('content'); ?>
    <?php /** @var \App\Models\BlogCategory $item */ ?>
    <form action="<?php echo e(route('blog.admin.categories.update', $item->id)); ?>" method="POST">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="container">
            <?php /** @var \Illuminate\Support\ViewErrorBag $errors */ ?>
            <?php if($errors->any()): ?>
                <div class="row justify-content-center">
                    <div class="col-md-11">
                        <div class="alert alert-danger" role="alert">
                            <button class="close" type="button" data-dismiss="alert" aria-label="Close"></button>
                            <span aria-hidden="true">x</span>
                            <?php echo e($errors->first()); ?>

                        </div>
                    </div>
                </div>

            <?php endif; ?>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <?php echo $__env->make('blog.admin.category.include.item_edit_main_col', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-4">
                <?php echo $__env->make('blog.admin.category.include.item_edit_add_col', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>