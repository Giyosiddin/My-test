<?php

namespace App\Http\Controllers\Blog;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

abstract class BaseController extends Controller
{
    use SoftDeletes;
}
