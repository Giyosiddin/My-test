<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 08.01.2020
 * Time: 11:33
 */

namespace App\Http\Controllers\Blog\Admin;

use App\Http\Controllers\Blog\BaseController as GuestBaseController;

abstract class BaseController extends GuestBaseController
{
/**
 * BaseController constructor
 */
    public function __construct()
    {

    }

}